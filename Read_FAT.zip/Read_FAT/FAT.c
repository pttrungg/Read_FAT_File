/*
 * @brief FAT.c
 * @file Source code
 */

#include "FAT.h"
#include "IO.h"

/*******************************************************************************
 * Definitions * 
 ******************************************************************************/
#define CONVERT_2BYTE_LITTLE(buff) ((uint16_t)(((uint8_t)(buff)[1] << 8) | (uint8_t)(buff)[0]))
#define CONVERT_4BYTE_LITTLE(buff) (uint32_t)(((uint8_t)(buff)[3] << 24) | ((uint8_t)(buff)[2] << 16) | ((uint8_t)(buff)[1] << 8) | ((uint8_t)(buff)[0]))

/* Boot info struct */
typedef struct _FAT_InforFAT_Struct_t_
{
    uint32_t sectorSize;       /* number of byte in a sector(byte) */
    uint32_t sectorPerCluster; /* number of sector in a cluster(sector) */
    uint32_t sectorPerFAT;     /* number of sector in FAT table(sector) */
    uint32_t clusterSize;      /* number of byte in a cluster(byte) */
    uint32_t rootSize;         /* number of sector in ROOT(sector) */
    uint32_t startRoot;        /* starting sector of ROOT */
    uint32_t startFATTable;    /* starting sector of FAT table */
    uint32_t startDataRegion;  /* starting sector of data region */
    uint32_t endOfFile;        /* FAT type : FAT12 = 0xFFF */
} FAT_InfoBoot_Struct_t;

/*******************************************************************************
 * Variables
 ******************************************************************************/
static FAT_InfoBoot_Struct_t s_fatBootInfo; 	// to store key data of boot
static uint32_t *sp_fatTable = NULL;			// to store fat table

/*******************************************************************************
 * Prototypes *
 ******************************************************************************/
/*
 * @brief read boot sector to get data
 * @params[in] no params in
 * @params[out] status: output status of function
 * @return true if operate right, otherwise false
 */
static bool FAT_HandleBootSector(void);

/*
 * @brief convert and store data of FAT table in a buffer (size = size of fat)
 * @params[in] no params in
 * @params[out] status: output status of function
 * @return true if operate right, otherwise false
 */
static bool FAT_ConvertFatTable(void);

/*
 * @brief read long name of entry 
 * @params[in] entryLFN: entry w/ long file name (att = 0x0F)
 * @params[in] entryLFNCount: number of LFN entry 
 * @params[in] longName: buffer to store LFN after taken from entryLFN
 * @params[out] no params out
 * @return no returned value
 */
static void FAT_ReadLongName(uint8_t *entryLFN, uint8_t entryLFNCount, uint8_t *longName);

/*
 * @brief handle a entry (data) and add it to head node
 * @params[in] pCurrent_Entry: pointer to current entry in node
 * @params[in] longName: a string contains entry name
 * @params[in] head_entry_list: head node of list
 * @params[out] no params out
 * @return no returned value
 */
static void FAT_HandleAEntry(uint8_t *pCurrent_Entry, uint8_t *longName, FAT_EntryList_Struct_t **head_entry_list);


/*******************************************************************************
 * Code
 ******************************************************************************/
static bool FAT_HandleBootSector(void)
{
    /* pointer to the memory area where the boot is stored after reading */
    uint8_t *buffer = NULL;
    /* status of function FAT_HandleBootSector */
    bool status;
    /* variable used to store the number of bytes read */
    uint16_t byte_read;

    buffer = (uint8_t *)malloc(sizeof(uint8_t) * 512);
    /* the Boot Sector is the first sector */
    byte_read = IO_ReadSector(0, buffer);
    /* byte per sector default = 512 */
    if (byte_read == 512)
    {
        status = true;
        /* read sector size and update */
        s_fatBootInfo.sectorSize = CONVERT_2BYTE_LITTLE((&buffer[0x0b]));
        if (512 != s_fatBootInfo.sectorSize)
        {
            IO_UpdateSectorSize(s_fatBootInfo.sectorSize);
        }
        s_fatBootInfo.sectorPerCluster = buffer[0X0D];
        s_fatBootInfo.sectorPerFAT = CONVERT_2BYTE_LITTLE(&buffer[0x16]);
        s_fatBootInfo.clusterSize = s_fatBootInfo.sectorSize * s_fatBootInfo.sectorPerCluster;
        /* size of root = number of root directory entries x Number byte of a entry */
        s_fatBootInfo.rootSize = (CONVERT_2BYTE_LITTLE((&buffer[0x11])) * 32) / s_fatBootInfo.sectorSize;
        s_fatBootInfo.startFATTable = CONVERT_2BYTE_LITTLE((&buffer[0x0e]));
        s_fatBootInfo.startRoot = s_fatBootInfo.startFATTable + buffer[0x10] * s_fatBootInfo.sectorPerFAT;
        s_fatBootInfo.startDataRegion = s_fatBootInfo.startRoot + s_fatBootInfo.rootSize;
        s_fatBootInfo.endOfFile = 0xFFF;

        free(buffer);
    }
    
    else
    {
        status = false;
    }

    return status;
}

/******************************************************************************/
static bool FAT_ConvertFatTable(void)
{
    /* status of function FAT_ConvertFatTable */
    bool status = true;
    
    /* pointer to the memory area where the FAT table is stored after reading */
    uint8_t *buffer = NULL;
    
    /* variable used to count the index */
    uint32_t index = 0;
    
    /* variable used to store the number of bytes read */
    uint32_t read_byte = 0;
    
    /* variable used to store the number of elements of the FAT  table */
    uint32_t number_element_table_fat = 0;
    
    /* variable used to store index of new FAT table*/
    uint32_t indexOfNewFat = 0;

    number_element_table_fat = s_fatBootInfo.sectorSize * s_fatBootInfo.sectorPerFAT;
    buffer = (uint8_t *)malloc(sizeof(uint8_t) * number_element_table_fat);
    
    /* read all FAT table into buffer */
    read_byte = IO_ReadMultiSector(s_fatBootInfo.startFATTable, s_fatBootInfo.sectorPerFAT, buffer);
    if (read_byte == number_element_table_fat)
    {
		/* endOfFile = 0xFFF */
        sp_fatTable = (uint32_t *)malloc(sizeof(uint32_t) * (number_element_table_fat * 2) / 3 + 1);

        for (index = 0; index < number_element_table_fat; index += 3)
        {
            sp_fatTable[indexOfNewFat] = (CONVERT_2BYTE_LITTLE(&buffer[index]) & 0xFFF);
            sp_fatTable[indexOfNewFat + 1] = (CONVERT_2BYTE_LITTLE((&buffer[(index + 1)])) >> 4);
            indexOfNewFat += 2;
        }
        
    }
    
    else
    {
        status = false;
    }
    
    free(buffer);

    return status;
}

/******************************************************************************/
static void FAT_ReadLongName(uint8_t *entryLFN, uint8_t entryLFNCount, uint8_t *longName)
{
    /* array store index unicode need get out*/
    uint8_t indexLFN[13] = {1, 3, 5, 7, 9, 14, 16};
    
    /* variable used to count */
    uint8_t index = 0;

    for (index = 0; index < 7; index++)
    {
        longName[(entryLFNCount - 1) * 7 + index] = entryLFN[indexLFN[index]];
    }
}

/******************************************************************************/
static void FAT_HandleAEntry(uint8_t *pCurrent_Entry, uint8_t *longName, FAT_EntryList_Struct_t **head_entry_list)
{
    /* variable used to count */
    uint8_t index;
    
    /* pointer to list */
    FAT_EntryList_Struct_t *pCurrent_entry_list = *head_entry_list;
    
    /* pointer after pCurrent */
    FAT_EntryList_Struct_t *pPrevious_entry_list = NULL;
    
    /* new  entry need add to list */
    FAT_EntryList_Struct_t *new_entry_list = NULL;

    new_entry_list = (FAT_EntryList_Struct_t *)malloc(sizeof(FAT_EntryList_Struct_t));
    
    /* short name */
    if (longName[0] == 0)
    {
        memcpy(new_entry_list->FATEntryList_EntryData.FATEntry_EntryName, pCurrent_Entry + FAT_OFFSET_SHORT_NAME, 8u);
        new_entry_list->FATEntryList_EntryData.FATEntry_EntryName[8] = '\0';
    }
    
    /* long name*/
    else 
    {
        for (index = 0; longName[index] != '\0'; index++)
        {
            new_entry_list->FATEntryList_EntryData.FATEntry_EntryName[index] = longName[index];
        }
        new_entry_list->FATEntryList_EntryData.FATEntry_EntryName[index] = '\0';
    }
    
    /* FATEntry_Extension */
    memcpy(new_entry_list->FATEntryList_EntryData.FATEntry_Extension,
           pCurrent_Entry + FAT_OFFSET_FATEntry_Extension, 3u);
    new_entry_list->FATEntryList_EntryData.FATEntry_Extension[3] = '\0';
    
    /* file attribute */
    if (*(pCurrent_Entry + FAT_OFFSET_ATTRIBUTE) == 0x10)
    {
        new_entry_list->FATEntryList_EntryData.FATEntry_FileAttributes = 0x10;
    }
    else
    {
        new_entry_list->FATEntryList_EntryData.FATEntry_FileAttributes = 0x00;
    }

    /* time create */
    new_entry_list->FATEntryList_EntryData.FATEntry_CreateTime.FATTime_Hours = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                   + FAT_OFFSET_TIME_CREATE))) >> 11);
    new_entry_list->FATEntryList_EntryData.FATEntry_CreateTime.FATTime_Minutes = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                     + FAT_OFFSET_TIME_CREATE))) >> 5) & 0x3F;
    new_entry_list->FATEntryList_EntryData.FATEntry_CreateTime.FATTime_Seconds = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                     + FAT_OFFSET_TIME_CREATE))) & 0x1F) * 2;
    /* date create */
    new_entry_list->FATEntryList_EntryData.FATEntry_CreateDate.FATDate_Year = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                  + FAT_OFFSET_DATE_CREATE))) >> 9) + 1980;
    new_entry_list->FATEntryList_EntryData.FATEntry_CreateDate.FATDate_Month = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                   + FAT_OFFSET_DATE_CREATE))) >> 5) & 0x07;
    new_entry_list->FATEntryList_EntryData.FATEntry_CreateDate.FATDate_Day = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                 + FAT_OFFSET_DATE_CREATE))) & 0x1F);
    /* time modify */
    new_entry_list->FATEntryList_EntryData.FATEntry_ModifyTime.FATTime_Hours = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                   + FAT_OFFSET_TIME_MODIFY))) >> 11);
    new_entry_list->FATEntryList_EntryData.FATEntry_ModifyTime.FATTime_Minutes = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                     + FAT_OFFSET_TIME_MODIFY))) >> 5) & 0x3F;
    new_entry_list->FATEntryList_EntryData.FATEntry_ModifyTime.FATTime_Seconds = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                     + FAT_OFFSET_TIME_MODIFY))) & 0x1F) * 2;
    /* date modify */
    new_entry_list->FATEntryList_EntryData.FATEntry_ModifyDate.FATDate_Year = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                  + FAT_OFFSET_DATE_MODIFY))) >> 9) + 1980;
    new_entry_list->FATEntryList_EntryData.FATEntry_ModifyDate.FATDate_Month = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                   + FAT_OFFSET_DATE_MODIFY))) >> 5) & 0x07;
    new_entry_list->FATEntryList_EntryData.FATEntry_ModifyDate.FATDate_Day = ((CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                                 + FAT_OFFSET_DATE_MODIFY))) & 0x1F);
    /* cluster starts in data region */
    new_entry_list->FATEntryList_EntryData.FATEntry_StartCluster = CONVERT_2BYTE_LITTLE((pCurrent_Entry 
                                                                     + FAT_OFFSET_FATEntry_StartCluster));
    /* size of file */
    if (CONVERT_4BYTE_LITTLE((pCurrent_Entry + FAT_OFFSET_SIZE_FILE)) % s_fatBootInfo.clusterSize == 0)
    {
        new_entry_list->FATEntryList_EntryData.FATEntry_FileSize = CONVERT_4BYTE_LITTLE((pCurrent_Entry 
                                                                     + FAT_OFFSET_SIZE_FILE));
    }
    else
    {
        new_entry_list->FATEntryList_EntryData.FATEntry_FileSize = (CONVERT_4BYTE_LITTLE((pCurrent_Entry 
                                    + FAT_OFFSET_SIZE_FILE)) / s_fatBootInfo.clusterSize + 1) * s_fatBootInfo.clusterSize;
    }
    new_entry_list->FATEntryList_Next = NULL;
    
    /* add to list */
    if (*head_entry_list == NULL)
    {
        *head_entry_list = new_entry_list;
    }
    else
    {
        /* add node entry to the end list */
        while (pCurrent_entry_list != NULL)
        {
            pPrevious_entry_list = pCurrent_entry_list;
            pCurrent_entry_list = pCurrent_entry_list->FATEntryList_Next;
        }
        pPrevious_entry_list->FATEntryList_Next = new_entry_list;
    }
}

/******************************************************************************/
FAT_error_code_t FAT_open(const int8_t *file_path)
{
    /* variable used to check status IO_init */
    IO_error_code_t check;
    /* variable used to check status  */
    FAT_error_code_t status = FAT_ErrorCode_Success;

    check = IO_Open(file_path);
    if (check == IO_ErrorCode_Success)
    {
        /* get data in boot into struct */
        if (true == FAT_HandleBootSector() && true == FAT_ConvertFatTable())
        {
            status = FAT_ErrorCode_Success;
        }
        else
        {
            status = FAT_ErrorCode_OpenFail;
        }
    }
    else
    {
        status = FAT_ErrorCode_OpenFail;
    }
    return status;
}

/******************************************************************************/
FAT_error_code_t FAT_ReadDirectory(const uint32_t FATEntry_StartCluster, FAT_EntryList_Struct_t **head_entry_list)
{
    uint8_t entryLFNCount = 0;
    uint8_t *longName;
    /* pointer to 32 bits of buffer */
    uint8_t *pEntry;
    
    /* pointer to the memory area where the data region is stored after reading */
    uint8_t *buffer = NULL;
    
    /* variable used to check when pEntry point outside buffer*/
    bool check_FAT_OVER;
    
    /*variable used to store index of buffer*/
    uint32_t index = 0;
    
    /* variable used to store the number of bytes read */
    uint32_t read_byte = 0;
    
    /* variable used to count the number of clusters from the FAT table */
    uint32_t count_cluster = 0;
    
    /* variable used to store position of cluster from the FAT table  */
    uint32_t position_cluster;
    
    /*  variable used to store starting sector to read */
    uint32_t start_sector;
    
    /* variable used to status of function FAT_ReadDirectory */
    FAT_error_code_t status = FAT_ErrorCode_Success;
    
    /* pointer to list */
    FAT_EntryList_Struct_t *pCurrent_entry_list = *head_entry_list;
    
    /* pointer after pCurrent */
    FAT_EntryList_Struct_t *pPrevious_entry_list = NULL;

    /* reset list*/
    while (pCurrent_entry_list != NULL)
    {
        pPrevious_entry_list = pCurrent_entry_list;
        pCurrent_entry_list = pCurrent_entry_list->FATEntryList_Next;
        free(pPrevious_entry_list);
    }
    *head_entry_list = NULL;


    /* read RDET with FATEntry_StartCluster = 0 */
    if (0 == FATEntry_StartCluster)
    {
        buffer = (uint8_t *)malloc(sizeof(uint8_t) * s_fatBootInfo.rootSize * s_fatBootInfo.sectorSize);
        read_byte = IO_ReadMultiSector(s_fatBootInfo.startRoot, s_fatBootInfo.rootSize, buffer);
            
        if (s_fatBootInfo.rootSize * s_fatBootInfo.sectorSize != read_byte)
        {
            status = FAT_ErrorCode_ReadDirectoryFail;
        }
    }
        
    /*  cluster 1 doesn't exist */
    else if (1 == FATEntry_StartCluster)
    {
        status = FAT_ErrorCode_ReadDirectoryFail;
    }
        
    /* if cluster is not 0 */
    else
    {
        /* count number of cluster in data region by FAT table */
        position_cluster = FATEntry_StartCluster;
        while (position_cluster != s_fatBootInfo.endOfFile)
        {
            count_cluster++;
            position_cluster = sp_fatTable[position_cluster];
        }
            
        /* size buffer = number of clusters * cluster size */
        buffer = (uint8_t *)malloc(sizeof(uint8_t) * count_cluster * s_fatBootInfo.clusterSize);
        position_cluster = FATEntry_StartCluster;
            
        while (position_cluster != s_fatBootInfo.endOfFile)
        {
            start_sector = s_fatBootInfo.startDataRegion + (position_cluster - 2) * s_fatBootInfo.sectorPerCluster;
                
            /* ghi lien tiep du lieu vao buffer */
            read_byte += IO_ReadMultiSector(start_sector, s_fatBootInfo.sectorPerCluster, &buffer[read_byte]);
                
            /* chuyen den cluster tiep theo */
            position_cluster = sp_fatTable[position_cluster];
            index += s_fatBootInfo.clusterSize;
        }
        /* neu so byte doc duoc bang so cluster * so sector tren 1 cluster * so byte 1 sector */
        if (count_cluster * s_fatBootInfo.clusterSize != read_byte)
        {
            status = FAT_ErrorCode_ReadDirectoryFail;
        }
    }
	

    /* add entries into list */
    pEntry = buffer;
    check_FAT_OVER = !FAT_OVER;
    longName = (uint8_t *)calloc(1, sizeof(uint8_t));
    do
    {
        if (*(pEntry) != FAT_BLANK)
        {
            if (*(pEntry + FAT_OFFSET_ATTRIBUTE) == 0x0F)
            {
                ++entryLFNCount;
                longName = (uint8_t *)realloc(longName, (sizeof(uint8_t)) * 7 * entryLFNCount);
                longName[7 * entryLFNCount] = '\0';
                FAT_ReadLongName((uint8_t *)pEntry, entryLFNCount, longName);
            }
            else
            {
                entryLFNCount = 0;
                FAT_HandleAEntry(pEntry, longName, head_entry_list);
                free(longName);
                longName = (uint8_t *)calloc(1, sizeof(uint8_t));
            }
        }
        
        /* con tro pEntry tro den 32 byte tiep theo -> de doc lien tiep cac entry */
        pEntry += 32;
        
        /* neu pEntry tro ra ngoai vung buff */
        if ((pEntry) == (uint8_t *)(&buffer + 1))
        {
            check_FAT_OVER = FAT_OVER;
        }
    } while (*(pEntry) != FAT_EMPTY && check_FAT_OVER != FAT_OVER);
    
    free(buffer);

    return status;
}

/******************************************************************************/

FAT_error_code_t FAT_ReadFile(const uint32_t FATEntry_StartCluster, uint8_t *buffer)
{
    /*variable used to store index of buffer*/
    uint32_t index = 0;
    
    /* variable used to count the number of clusters from the FAT table */
    uint32_t count_cluster = 0;
    
    /* variable used to store position of cluster from the FAT table  */
    uint32_t position_cluster;
    
    /* variable used to store the number of bytes read */
    uint32_t read_byte = 0;
    
    /*  variable used to store starting sector to read */
    uint32_t start_sector;
    
    /* variable used to status of function FAT_ReadDirectory */
    FAT_error_code_t status = FAT_ErrorCode_Success;

    position_cluster = FATEntry_StartCluster;
    while (position_cluster != s_fatBootInfo.endOfFile)
    {
        count_cluster++;
        start_sector = s_fatBootInfo.startDataRegion + (position_cluster - 2) * s_fatBootInfo.sectorPerCluster;
        read_byte += IO_ReadMultiSector(start_sector, s_fatBootInfo.sectorPerCluster, &buffer[read_byte]);
        position_cluster = sp_fatTable[position_cluster];
    }
    
    /* neu so byte doc duoc bang so cluster * so sector tren 1 cluster * so byte 1 sector */
    if (count_cluster * s_fatBootInfo.clusterSize != read_byte)
    {
        status = FAT_ErrorCode_ReadDirectoryFail;
    }

    return status;
}

/******************************************************************************/
FAT_error_code_t FAT_close(void)
{
    free(sp_fatTable);
    IO_Close();
}
