/* 
 * @file IO.c
 * @brief Source code
 */ 

/*******************************************************************************
 * Included library *
 ******************************************************************************/
#include "IO.h"

/*******************************************************************************
 * Definitions *
 ******************************************************************************/
static FILE *fp;
uint16_t sectorSize = 512;

/*******************************************************************************
 * Code *
 ******************************************************************************/
IO_error_code_t IO_Open(const int8_t *file_path)
{
    IO_error_code_t ret=IO_ErrorCode_Success;
	fp = fopen(file_path,"rb");
	if(fp==NULL)
	{
        ret = IO_ErrorCode_OpenFail;
	}
	
	return ret;
}

/****************************************************************************/
uint32_t IO_ReadSector(uint32_t index, uint8_t *buffer)
{
	uint32_t byte_read=0;
	
	/* fseek to set position indicator to index and  return 0 if success */
    if(fp!=NULL)
	{
		/* fread return the number of full items successfully read */
		if(0 == fseek (fp,(sectorSize * index) , SEEK_SET))
		{
			byte_read = fread(buffer, 1, sectorSize, fp);
		}
	}
	return byte_read;
}

/****************************************************************************/
uint32_t IO_ReadMultiSector(uint32_t index, uint32_t num, uint8_t *buffer)
{
   
	uint32_t byteRead = 0;
	
	/* fseek to set position indicator to index and  return 0 if success */
    if(fp != NULL)
	{
		/* fread return the number of full items successfully read */
		if(0 == fseek (fp,(sectorSize * index) , SEEK_SET))
		{
			byteRead = fread(buffer, 1, (sectorSize * num), fp);
			
		}
	}
	return byteRead;
}

/****************************************************************************/
IO_error_code_t IO_Close(void)
{
	IO_error_code_t ret;
	
	if(fclose(fp) != 0)
	{
        ret = IO_ErrorCode_CloseFail ;
	}
}

/****************************************************************************/
IO_error_code_t IO_UpdateSectorSize(const uint16_t new_sectorSize)
{
	IO_error_code_t ret;
    if( 0 == (new_sectorSize % 512) )
	{
		sectorSize = new_sectorSize;
		ret = IO_ErrorCode_Success;
	}
	else
	{
		ret= IO_ErrorCode_UpdateFail;
	}
	return ret;
}
 
