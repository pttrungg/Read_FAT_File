#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "FAT.h"
#include "UI.h"

/******************************************************************************
 * Code *
 ******************************************************************************/
int main(void)
{
    /* buffer to store data to print */
    uint8_t *buffer = NULL;
    
    /* variable used to enter user's choice */
    uint16_t choice = 0;
    
    /* variable used to store number of entry */
    uint16_t number_entry = 0;
    
    /* variable used to count number of entry */
    uint16_t count_entry = 1;
    
    /*  variable used to store position of cluster */
    uint16_t position_cluster = 0;
    
    /* pointer to the top list */
    FAT_EntryList_Struct_t *head_entry_list = NULL;
    FAT_EntryList_Struct_t *pCurrent_entry_list = NULL;
    FAT_error_code_t ret= FAT_ErrorCode_Success;
    
    ret = FAT_open("floppy1.img");
    
    if(FAT_ErrorCode_Success == ret)
    {
        /* read root directory */
        ret = FAT_ReadDirectory(0, &head_entry_list);
        
        if(FAT_ErrorCode_Success == ret)
        {
        	/* print root's content */
            UI_PrintDirectory(head_entry_list, &number_entry);
            printf("\n--------------------------------------------------------------\n");
            printf("Choice: ");
            
            /* if choice is out of range of number_entry, clear buffer cache */
            while ( (scanf("%d", &choice)) == 0 || (choice <= 0 || choice > number_entry) ) 
            {
                fflush(stdin); 
            }
            
            /* if choice is in range of number_entry */
            while ( (choice >= 0 && choice <= number_entry) )
            {
                system("cls"); /* clear console screen */
                count_entry = 1;
                pCurrent_entry_list = head_entry_list; /* pCurrent_entry_list now contains content of head (entries) */
                
                while (pCurrent_entry_list != NULL && choice != count_entry)
                {
                    count_entry++;
                    pCurrent_entry_list = pCurrent_entry_list->FATEntryList_Next;
                }
                
                /* if a choice is a file, then read it and print its data */
                if (pCurrent_entry_list->FATEntryList_EntryData.FATEntry_FileAttributes == IS_FILE)
                {
                    buffer = (uint8_t *)malloc((sizeof(uint8_t)) 
                        		*pCurrent_entry_list->FATEntryList_EntryData.FATEntry_FileSize);
                    ret = FAT_ReadFile(pCurrent_entry_list->FATEntryList_EntryData.FATEntry_StartCluster, buffer);
                    
                    if(FAT_ErrorCode_Success == ret)
                    {
                    	/* print out content of file */
                        UI_PrintFile(buffer, pCurrent_entry_list->FATEntryList_EntryData.FATEntry_FileSize);
                        free(buffer);
                        
                        /* back directory after read file */
                        printf("\n\nPress 0 to back: ");
                        
                        while ((0 == scanf(" %d", &choice)) || choice != 0)
                        {
                            fflush(stdin);
                        }
                        
                        number_entry = 0;
                        system("cls");
                        
                        if(choice == 0 && head_entry_list->FATEntryList_EntryData.FATEntry_EntryName[0] != '.')
                        {
                            ret = FAT_ReadDirectory(0, &head_entry_list);
                            
                            if (FAT_ErrorCode_Success == ret)
                            {
                                UI_PrintDirectory(head_entry_list, &number_entry);
                            }
                            else
                            {
                                ret= FAT_ErrorCode_ReadDirectoryFail;
                            }
                        }
                        
                        else
                        {
                            ret = FAT_ReadDirectory(head_entry_list->FATEntryList_EntryData.FATEntry_StartCluster
									, &head_entry_list);
                            if(FAT_ErrorCode_Success == ret)
                            {
                                UI_PrintDirectory(head_entry_list, &number_entry);
                            }
                        }
                    }
                    
                    else
                    {
                        ret = FAT_ErrorCode_ReadFileFail;
                    }
                }
                
                /* if a choice is a directory, then read it and print its data */
                else if (pCurrent_entry_list->FATEntryList_EntryData.FATEntry_FileAttributes == IS_FOLDER)
                {
//                    number_entry = 0;
                    FAT_ReadDirectory(pCurrent_entry_list->FATEntryList_EntryData.FATEntry_StartCluster
                                            , &head_entry_list);
                    if(FAT_ErrorCode_Success == ret)
                    {
                        UI_PrintDirectory(head_entry_list, &number_entry);
                    }
                    else
                    {
                        ret = FAT_ErrorCode_ReadDirectoryFail;
                    }
                }
                
                if (FAT_ErrorCode_Success == ret)
                {
                    printf("\n\nChoice: ");
                    while ( (0 == scanf("%d", &choice)) || (choice <= 0 || choice > number_entry) )
                    {
                        fflush(stdin);
                    }  
                }
            }
    	}
        
        else
        {
            ret = FAT_ErrorCode_ReadDirectoryFail;
        }
        
        ret = FAT_close();
        
        if (FAT_ErrorCode_Success == ret)
        {
            ret=FAT_ErrorCode_CloseFail;
    }
    
    else
    {
        ret = FAT_ErrorCode_CloseFail;
	}	
    
	}
    return 0;
}
