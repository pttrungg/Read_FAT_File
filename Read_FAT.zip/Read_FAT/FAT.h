/*
 * @file FAT.h 
 * @brief This library provides some functions to deal w/ FAT12 file
 */

#ifndef _FAT_H_
#define _FAT_H_
	#include <stdio.h>
	#include <stdint.h>
	#include <stdbool.h>
	#include <stdlib.h>
	#include <string.h>

/*******************************************************************************
 * Definitions *
 ******************************************************************************/
#define FAT_BLANK (0x00, 0xE5)
#define FAT_EMPTY 0x00
#define FAT_OFFSET_SHORT_NAME 0x00
#define FAT_OFFSET_FATEntry_Extension 0x08
#define FAT_OFFSET_ATTRIBUTE 0X0B
#define FAT_OFFSET_TIME_CREATE 0x0E
#define FAT_OFFSET_DATE_CREATE 0x10
#define FAT_OFFSET_TIME_MODIFY 0x16
#define FAT_OFFSET_DATE_MODIFY 0x18
#define FAT_OFFSET_FATEntry_StartCluster 0x1A
#define FAT_OFFSET_SIZE_FILE 0x1C
#define FAT_ATTRIBUTE_LONG_NAME 0x0F
#define FAT_OVER false
 
/* Date struct */
typedef struct __FAT__date_Struct_t_
{
    uint16_t FATDate_Year;
    uint8_t FATDate_Month;
    uint8_t FATDate_Day;
} FAT_date_Struct_t;

/* Time struct */
typedef struct __FAT__time_Struct_t_
{
    uint8_t FATTime_Hours;
    uint8_t FATTime_Minutes;
    uint8_t FATTime_Seconds;
} FAT_time_Struct_t;

/* Entry struct */
typedef struct
{
    uint8_t FATEntry_EntryName[255]; 		/* include short name and long name */
    uint8_t FATEntry_Extension[4];
    uint8_t FATEntry_FileAttributes; 		/* type file */
    FAT_time_Struct_t FATEntry_CreateTime;
    FAT_date_Struct_t FATEntry_CreateDate;
    FAT_time_Struct_t FATEntry_ModifyTime;
    FAT_date_Struct_t FATEntry_ModifyDate;
    uint16_t FATEntry_StartCluster; 		/* cluster start data of entry */
    uint32_t FATEntry_FileSize;     		/* size  data of entry */
} FAT_Entry_Struct_t;

/* Node struct  */
typedef struct __FAT_EntryList_Struct_t_
{
    FAT_Entry_Struct_t FATEntryList_EntryData;
    struct __FAT_EntryList_Struct_t_ *FATEntryList_Next;
} FAT_EntryList_Struct_t;

/* Error Code */
typedef enum
{
    FAT_ErrorCode_Success = 0,
    FAT_ErrorCode_OpenFail = 1,
    FAT_ErrorCode_ReadDirectoryFail = 2,
    FAT_ErrorCode_ReadFileFail = 3,
    FAT_ErrorCode_CloseFail = 4,
} FAT_error_code_t;

/*******************************************************************************
 * Protoypes *
 ******************************************************************************/

/*
 * @brief Open file, read boot and convert table FAT
 * @params[in] filePath: the path to file 
 * @params[out] status: output status of the function
 * @return status: 0 if success, 1 if fail
 */
FAT_error_code_t FAT_open(const int8_t *file_path);

/*
 * @brief Read directory (folder) and add entry into list
 * @params[in] FATEntry_StartCluster: starting cluster to read from
 * @params[in] head_entry_list: pointer to the top of list (head node)
 * @params[out] status: output status of the function
 * @return status: 0 if success, 2 if fail
 */
FAT_error_code_t FAT_ReadDirectory(const uint32_t FATEntry_StartCluster, FAT_EntryList_Struct_t **head_entry_list);

/*
 * @brief Read content of file and store to the buffer
 * @params[in] FATEntry_StartCluster: starting cluster to read from
 * @params[in] buffer: an allocated buffer (size = size of file)
 * @params[out] status: output status of the function
 * @return status: 0 if success, 3 if fail
 */
FAT_error_code_t FAT_ReadFile(const uint32_t FATEntry_StartCluster, uint8_t *buffer);

/*
 * @brief Function to close file 
 * @params[in] no params in
 * @params[out] no params out
 * @return 0 if success, 3 if fail 
 */
FAT_error_code_t FAT_close(void);

#endif /* _FAT_H_ */
