#ifndef _UI_H_
#define _UI_H_
	#include "FAT.h"

/******************************************************************************
 * Definitions
 ******************************************************************************/
#define IS_FILE 0x00
#define IS_FOLDER 0x10

/******************************************************************************
 * Prototypes
 ******************************************************************************/
 
/*
 * @brief print content of directory
 * @params[in] head_entry_list: head node to print (pass by value)
 * @params[in] number_entry: to print number of entry 
 * @params[out] no params out
 * @return no returned value
 */
void UI_PrintDirectory(FAT_EntryList_Struct_t *head_entry_list, uint16_t *number_entry);

/*
 * @brief print content of file
 * @params[in] buffer: buffer string w/ data of file 
 * @params[in] size: size of file
 * @params[out] no params out
 * @return no returned value
 */
void UI_PrintFile(uint8_t *buffer, uint32_t size);

/*
 * @brief show error code
 * @params[in] val: value to check status 
 * @params[out] no params out
 * @return no returned value
 */
void UI_ShowErrorCode(uint16_t val);

#endif /* _UI_H_ */
