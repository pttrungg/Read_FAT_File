/*******************************************************************************
 * Include Library *
 ******************************************************************************/
#include "UI.h"

/*******************************************************************************
 * Code *
 ******************************************************************************/

void UI_PrintDirectory(FAT_EntryList_Struct_t *head_entry_list, uint16_t *number_entry)
{
    FAT_EntryList_Struct_t *pCurrent_entry_list = head_entry_list;
    *number_entry = 0;

    printf("\n\t%-15s %-15s %-15s %-15s %-15s\n", "|Name|", "|Type|", "|Size|", "|Date|", "|Time|");
    while (pCurrent_entry_list != NULL)
    {
        (*number_entry)++;
        printf("\n%5d", *number_entry);
        if(pCurrent_entry_list->FATEntryList_EntryData.FATEntry_EntryName[0] == '.')
        {
            if(pCurrent_entry_list->FATEntryList_EntryData.FATEntry_EntryName[1] == '.')
            {
                printf("   back");
            }
            else
            {
                printf(" ");
            }  
        }
        else
        {
        
            if (pCurrent_entry_list->FATEntryList_EntryData.FATEntry_FileAttributes == IS_FILE)
            {
                printf("\t%-15s ", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_EntryName);
                printf("%-15s ", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_Extension);
                printf("%d KB\t\t",pCurrent_entry_list->FATEntryList_EntryData.FATEntry_FileSize/1024);
       			printf("%2.2d/", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyDate.FATDate_Day);
                printf("%2.2d/", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyDate.FATDate_Month);
                printf("%d\t", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyDate.FATDate_Year);
                printf("%2.2d:", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyTime.FATTime_Hours);
                printf("%2.2d:", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyTime.FATTime_Minutes);
                printf("%2.2d", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyTime.FATTime_Seconds); 
            }
            else if (pCurrent_entry_list->FATEntryList_EntryData.FATEntry_FileAttributes == IS_FOLDER)
            {
                printf("\t%-15s ", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_EntryName);
                printf("%-15s \t\t", "Folder"); //file_extension
                
                printf("%2.2d/", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyDate.FATDate_Day);
                printf("%2.2d/", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyDate.FATDate_Month);
                printf("%d\t", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyDate.FATDate_Year);  
                printf("%2.2d:", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyTime.FATTime_Hours);
                printf("%2.2d:", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyTime.FATTime_Minutes);
                printf("%2.2d", pCurrent_entry_list->FATEntryList_EntryData.FATEntry_ModifyTime.FATTime_Seconds);
      
            }   
        }
    pCurrent_entry_list = pCurrent_entry_list->FATEntryList_Next;
    }
}

/*****************************************************************/
void UI_PrintFile(uint8_t *buffer, uint32_t size)
{
    uint32_t index;
    for(index = 0; index < size; index++)
    {
    	/* Print char by char */
        printf("%c", buffer[index]);
    }
}

/*****************************************************************/
void UI_ShowErrorCode(uint16_t val) 
{
	switch(val) 
	{
		case 1:
			printf("\nCan't open file !!!");
			break;
		case 2:
			printf("\nCan't read directory !!!");
			break;
		case 3:
			printf("\nCan't read file !!!");
			break;
		case 4:
			printf("\nCan't close fail !!!");
			break;
	}		
}


