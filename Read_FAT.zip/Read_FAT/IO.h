#ifndef _IO_H_
#define _IO_H_
	#include <stdio.h>
	#include <stdint.h>

/*******************************************************************************
 * Definitions *
 ******************************************************************************/
typedef enum
{
    IO_ErrorCode_Success = 0,
    IO_ErrorCode_OpenFail = 1,
    IO_ErrorCode_UpdateFail = 2,
    IO_ErrorCode_CloseFail = 3,
}IO_error_code_t;
 
/*******************************************************************************
 * Prototypes * 
 ******************************************************************************/

/*
 * @brief initialze a stream to file
 * @params[in] no params in
 * @params[out] status: output status of function
 * @return true if operate right, otherwise false
 */
IO_error_code_t IO_Open(const int8_t *file_path);

/*
 * @brief read a sector at index-th position 
 * @params[in] index: position of sector
 * @params[in] buffer: a string to store data 
 * @params[out] byte_read: number of bytes are  read successfully
 * @return byte_read
 */
uint32_t IO_ReadSector(uint32_t index, uint8_t *buffer);

/*
 * @brief read multi sector from index-th position 
 * @params[in] index: position of sector
 * @params[in] num: number of sector want to read from index
 * @params[in] buffer: a string to store data 
 * @params[out] byte_read: number of bytes are  read successfully
 * @return byte_read
 */
uint32_t IO_ReadMultiSector(uint32_t index, uint32_t num, uint8_t *buffer);

/*
 * @brief de-initialize stream to file
 * @params[in] no params in
 * @params[out] ret: returned value to check status of function
 * @return ret: 0 if success, otherwise 3
 */
IO_error_code_t IO_Close(void);

/*
 * @brief update sector size if there is any change
 * @params[in] new_sectorSize: new sector size to update - must be divisible to 0
 * @params[out] ret: returned value to check status of function
 * @return ret: 0 if success, otherwise 2
 */
IO_error_code_t IO_UpdateSectorSize(const uint16_t new_sectorSize);

#endif /* _IO_H_ */

